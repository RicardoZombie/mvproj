<?php
// Inclua o arquivo de conexão
include 'conn.php';

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera os dados do formulário
    $tipo = $_POST["tipo"];
    $nome = $_POST["nome"];
    $ano = $_POST["ano"];
    $idioma = $_POST["idioma"];
    $sinopse = $_POST["sinopse"];
    $temporadas = isset($_POST["temporadas"]) ? $_POST["temporadas"] : null;

    // Verifica se foi feito upload de uma imagem
    if ($_FILES["capa"]["name"]) {
        // Diretório de destino para o upload da imagem
        $target_dir = "media/";

        // Gera um nome único para a imagem
        $imagem_nome = uniqid() . '_' . basename($_FILES["capa"]["name"]);

        // Caminho completo para a imagem no servidor
        $target_file = $target_dir . $imagem_nome;

        // Move a imagem para o diretório de destino
        if (move_uploaded_file($_FILES["capa"]["tmp_name"], $target_file)) {
            // Query para inserir os dados no banco de dados
            $sql = "INSERT INTO filmes_series (tipo, nome, capa, ano, idioma, sinopse, temporadas) VALUES ('$tipo', '$nome', '$imagem_nome', '$ano', '$idioma', '$sinopse', '$temporadas')";

            if ($conn->query($sql) === TRUE) {
                echo "Filme/Série adicionado com sucesso!";
            } else {
                echo "Erro ao adicionar filme/série: " . $conn->error;
            }
        } else {
            echo "Erro ao fazer upload da imagem.";
        }
    } else {
        echo "Por favor, selecione uma imagem.";
    }
}

// Fecha a conexão
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Administração - CINEMA ONLINE</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/b7b168c510.js" crossorigin="anonymous"></script>
  <style>
    body {
      background-color: black;
      color: white;
      margin: 0;
      padding: 0;
    }
    .top-bar {
      background-color: rgba(0, 0, 0, 0.8);
      padding: 10px 0;
      text-align: center;
      z-index: 1000;
    }
    .admin-title {
      font-family: 'Bebas Neue', sans-serif;
      font-size: 2.5em;
      color: red;
      text-align: center;
      margin-top: 20px; /* Ajuste a distância conforme necessário */
    }
    .admin-form {
      margin-top: 20px; /* Ajuste a distância conforme necessário */
    }
    .btn-add {
      background-color: red;
      color: white;
    }
  </style>
</head>
<body>

  <div class="top-bar">
    <h1 class="admin-title">Administração - CINEMA ONLINE</h1>
  </div>

  <div class="container admin-form">
    <form>
      <div class="mb-3">
        <label for="tipo">Tipo:</label>
        <select class="form-select" id="tipo" name="tipo">
          <option value="filme">Filme</option>
          <option value="serie">Série</option>
        </select>
      </div>
      <div class="mb-3">
        <label for="capa" class="form-label">Capa:</label>
        <input class="form-control" type="file" id="capa" name="capa">
      </div>
      <div class="mb-3">
        <label for="link" class="form-label">Link:</label>
        <input class="form-control" type="text" id="link" name="link">
      </div>
      <div class="mb-3">
        <label for="ano" class="form-label">Ano:</label>
        <input class="form-control" type="text" id="ano" name="ano">
      </div>
      <div class="mb-3">
        <label for="idioma" class="form-label">Idioma:</label>
        <input class="form-control" type="text" id="idioma" name="idioma">
      </div>
      <div class="mb-3">
        <label for="sinopse" class="form-label">Sinopse:</label>
        <textarea class="form-control" id="sinopse" name="sinopse" rows="3"></textarea>
      </div>
      <button type="submit" class="btn btn-add"><i class="fas fa-plus"></i> Adicionar Filme/Série</button>
    </form>
  </div>

  <div class="container">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Capa</th>
          <th scope="col">Nome</th>
          <th scope="col">Tipo</th>
          <th scope="col">Ano</th>
          <th scope="col">Idioma</th>
          <th scope="col">Link</th>
          <th scope="col">Sinopse</th>
          <th scope="col">Ações</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><img src="capa_filme1.jpg" alt="Capa Filme 1" style="max-width: 100px;"></td>
          <td>Nome do Filme 1</td>
          <td>Filme</td>
          <td>2022</td>
          <td>Português</td>
          <td><a href="link_filme1">Assistir</a></td>
          <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</td>
          <td>
            <button class="btn btn-danger"><i class="fas fa-trash"></i> Excluir</button>
          </td>
        </tr>
        <tr>
          <td><img src="capa_filme2.jpg" alt="Capa Filme 2" style="max-width: 100px;"></td>
          <td>Nome do Filme 2</td>
          <td>Filme</td>
          <td>2023</td>
          <td>Inglês</td>
          <td><a href="link_filme2">Assistir</a></td>
          <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</td>
          <td>
            <button class="btn btn-danger"><i class="fas fa-trash"></i> Excluir</button>
          </td>
        </tr>
        <tr>
          <td><img src="capa_serie1.jpg" alt="Capa Série 1" style="max-width: 100px;"></td>
          <td>Nome da Série 1</td>
          <td>Série</td>
          <td>2020</td>
          <td>Inglês</td>
          <td><a href="link_serie1">Assistir</a></td>
          <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</td>
          <td>
            <button class="btn btn-danger"><i class="fas fa-trash"></i> Excluir</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>