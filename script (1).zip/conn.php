<?php

// Dados de conexão
$servername = "localhost";
$username = "root";
$password = "skate200";
$database = "movies"; // Nome do banco de dados

// Criar conexão
$conn = new mysqli($servername, $username, $password, $database);

// Verificar conexão
if ($conn->connect_error) {
  die("Erro de conexão: " . $conn->connect_error);
}

// echo "Conexão bem sucedida"; // Comente ou remova esta linha após verificar a conexão

?>