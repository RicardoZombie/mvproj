<?php
// Inclua o arquivo de conexão
include 'conn.php';

// Inicializa a variável de busca
$busca = "";

// Verifica se foi feita uma busca
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["busca"])) {
    $busca = $_POST["busca"];
}

// Monta a query SQL
$sql = "SELECT * FROM filmes_series";
if (!empty($busca)) {
    $sql .= " WHERE nome LIKE '%$busca%'";
}

// Executa a query
$result = $conn->query($sql);




// Fecha a conexão
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Filmes - CINEMA ONLINE</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/b7b168c510.js" crossorigin="anonymous"></script>
  <style>
    body {
      background-color: black;
      color: white;
      margin: 0;
      padding: 0;
    }
    .top-bar {
      background-color: rgba(0, 0, 0, 0.8);
      padding: 10px 0;
      text-align: center;
      z-index: 1000;
    }
    .search-bar {
      background-color: rgba(0, 0, 0, 0.8);
      padding: 10px 0;
      text-align: center;
      margin-bottom: 20px; /* Ajuste a distância conforme necessário */
    }
    .search-bar input[type="search"] {
      border-radius: 20px;
      width: 80%;
      max-width: 500px;
      padding: 10px;
      margin-bottom: 10px;
    }
    .cinema-font {
      font-family: 'Bebas Neue', sans-serif;
      font-size: 2.5em;
      color: red;
      text-align: center;
      margin-top: 20px; /* Ajuste a distância conforme necessário */
    }
    .movie-list {
      text-align: center;
      margin-top: 20px; /* Ajuste a distância conforme necessário */
    }
    .movie {
      margin-bottom: 30px;
    }
    .movie img {
      max-width: 100%;
      height: auto;
    }
    .movie-info {
      margin-top: 10px;
      text-align: left; /* Alinha o texto à esquerda */
    }
    .btn-watch {
      background-color: red;
      color: white;
      width: 100%; /* Ajuste o tamanho do botão para ocupar 100% do espaço */
    }
  </style>
</head>
<body>

  <div class="top-bar">
    <h1 class="cinema-font">CINEMA ONLINE</h1>
  </div>

  <div class="container">
    <div class="search-bar d-flex justify-content-center">
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Pesquisar filmes" aria-label="Search">
        <button class="btn btn-danger" type="submit"><i class="fas fa-search"></i></button>
      </form>
    </div>
  </div>

  <div class="container movie-list">
    <div class="row">
      <?php
      // Verifica se encontrou algum resultado
if ($result->num_rows > 0):
    // Exibe os resultados
    echo "<ul>";
    while ($row = $result->fetch_assoc()) :
        echo "<li>" . $row["nome"] . "</li>";
    
    echo "</ul>";
      ?>
      <div class="col-md-4">
        <div class="movie">
          <img src="<?php $Row["capa"]  ?>" alt="Filme 1">
          <div class="movie-info">
            <h3><?php $Row["nome"]  ?></h3>
            <p>Tipo: <?php $Row["tipo"]  ?></p>
            <p>Idioma: <?php $Row["idioma"]  ?></p>
            <p>Ano: <?php $Row["ano"]  ?></p>
            <p>Sinopse: <?php $Row["sinopse"]  ?></p>
            <a href="<?php $Row["link"]  ?>"><button class="btn btn-watch"><i class="fas fa-play"></i> Assistir</button></a>
          </div>
        </div>
      </div>
      <?php
      endwhile;
      ?>
      <div class="col-md-4">
        <div class="movie">
          <img src="filme.jpg" alt="Filme 2">
          <div class="movie-info">
            <h3>Nome do Filme 2</h3>
            <p>Tipo: Filme</p>
            <p>Idioma: Inglês</p>
            <p>Ano: 2023</p>
            <p>Sinopse: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer condimentum lacus vel augue dignissim, quis vestibulum velit lacinia.</p>
            <button class="btn btn-watch"><i class="fas fa-play"></i> Assistir</button>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="movie">
          <img src="filme.jpg" alt="Filme 3">
          <div class="movie-info">
            <h3>Nome do Filme 3</h3>
            <p>Tipo: Filme</p>
            <p>Idioma: Espanhol</p>
            <p>Ano: 2024</p>
            <p>Sinopse: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer condimentum lacus vel augue dignissim, quis vestibulum velit lacinia.</p>
            <button class="btn btn-watch"><i class="fas fa-play"></i> Assistir</button>
          </div>
        </div>
      </div>
    </div>
    <?php
    else :
      echo "<h1>Nenhum filme ou série encontrado.</h1>";
    endif;
    ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>